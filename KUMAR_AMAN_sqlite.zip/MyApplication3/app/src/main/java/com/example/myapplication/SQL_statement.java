package com.example.myapplication;

public class SQL_statement {
}
