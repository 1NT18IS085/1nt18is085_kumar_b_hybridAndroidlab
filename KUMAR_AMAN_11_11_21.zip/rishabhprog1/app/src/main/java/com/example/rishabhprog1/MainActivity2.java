package com.example.rishabhprog1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent it1=getIntent();
        String sum=it1.getStringExtra("sum");
        //System.out.println(sum);
        TextView res=findViewById(R.id.textView);

        res.setText(sum);
    }
}
