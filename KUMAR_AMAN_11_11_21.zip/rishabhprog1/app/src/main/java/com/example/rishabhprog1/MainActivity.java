package com.example.rishabhprog1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(getApplicationContext(), "started", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "paused", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(getApplicationContext(), "resumed", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(getApplicationContext(), "stopped", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Toast.makeText(getApplicationContext(),"addition", Toast.LENGTH_SHORT).show();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button ADD=findViewById(R.id.button);
        ADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                EditText num1=findViewById(R.id.num1);
                EditText num2=findViewById(R.id.num2);
                Toast.makeText(getApplicationContext(),"THIS IS THE RESULT", Toast.LENGTH_LONG).show();
                int n1=Integer.parseInt(num1.getText().toString());
                int n2=Integer.parseInt(num2.getText().toString());
                int res=n1+n2;
                Intent it =new Intent(getApplicationContext(),MainActivity2.class);
//                String str1="hello";
              it.putExtra("sum",Integer.toString(res));
                startActivity(it);

            }
        });
    }
}
